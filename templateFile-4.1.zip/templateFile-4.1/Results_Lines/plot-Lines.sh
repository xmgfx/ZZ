#!/bin/bash

/bin/rm -f *~ *.png

python3  ./plot-Lines.py


