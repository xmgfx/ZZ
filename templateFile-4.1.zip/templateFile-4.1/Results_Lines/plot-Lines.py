# -*- coding: utf-8 -*-
"""
Created on Mon Aug 25 10:06:33 2025

@author: Administrator
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def read_solver_info(filename):
    """
    读取solverInfo.dat文件，提取指定列数据
    返回格式：二维数组，每个子数组包含[第1列, 第4列, 第7列, 第10列, 第15列]
    """
    result = []
    try:
        with open(filename, 'r') as file:
            # 跳过前两行
            for _ in range(2):
                next(file)
            
            # 处理剩余行
            for line_num, line in enumerate(file, start=3):  # 行号从3开始计数
                # 清理并分割行内容
                cleaned_line = line.strip()
                if not cleaned_line:  # 跳过空行
                    continue
                
                columns = cleaned_line.split()
                
                # 验证列数是否足够
                if len(columns) < 15:
                    print(f"警告：第{line_num}行列数不足（需要15列，实际{len(columns)}列），已跳过")
                    continue
                
                try:
                    # 提取指定列（索引从0开始）
                    selected = [
                        columns[0],   # 第1列
                        columns[3],   # 第4列
                        columns[6],   # 第7列
                        columns[9],   # 第10列
                        columns[14],   # 第15列
                        columns[19],   # 第20列
                        columns[24],   # 第25列
                        columns[29]   # 第30列 
                        ]                   
                    result.append(selected)
                except IndexError:
                    print(f"错误：第{line_num}行数据格式异常")
                    continue
                    
    except FileNotFoundError:
        print(f"错误：文件 {filename} 未找到")
    except Exception as e:
        print(f"未知错误：{str(e)}")
    
    return np.array(result, dtype=float)

def read_T_Average(filename):
    """
    读取solverInfo.dat文件，提取指定列数据
    返回格式：二维数组，每个子数组包含[第1列, 第4列, 第7列, 第10列, 第15列]
    """
    result = []
    try:
        with open(filename, 'r') as file:
            # 跳过前两行
            for _ in range(4):
                next(file)
            
            # 处理剩余行
            for line_num, line in enumerate(file, start=5):  # 行号从5开始计数
                # 清理并分割行内容
                cleaned_line = line.strip()
                if not cleaned_line:  # 跳过空行
                    continue
                
                columns = cleaned_line.split()                

                try:
                    # 提取指定列（索引从0开始）
                    selected = [
                        columns[0],   # 第1列
                        columns[1]   # 第2列
                        ]                   
                    result.append(selected)
                except IndexError:
                    print(f"错误：第{line_num}行数据格式异常")
                    continue
                    
    except FileNotFoundError:
        print(f"错误：文件 {filename} 未找到")
    except Exception as e:
        print(f"未知错误：{str(e)}")
    
    return np.array(result, dtype=float)

if __name__ == "__main__":
    # Residuals
    plt.figure()
    data = read_solver_info("../postProcessing/residuals/0/solverInfo.dat")
    labels = ['Ux', 'Uy', 'Uz', 'k', 'P', 'T', 'omega'] 
    plt.semilogy(data[:,0],data[:,1],label=labels[0])
    plt.semilogy(data[:,0],data[:,2],label=labels[1])    
    plt.semilogy(data[:,0],data[:,3],label=labels[2])
    plt.semilogy(data[:,0],data[:,5],label=labels[4])
    plt.semilogy(data[:,0],data[:,6],label=labels[5])
    plt.semilogy(data[:,0],data[:,4],label=labels[3])    
    plt.semilogy(data[:,0],data[:,7],label=labels[6])
    plt.legend()
    plt.tight_layout()
    plt.xlabel('Iteration', fontsize=14)
    plt.ylabel('Residuals', fontsize=14)  
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.savefig('residual_plot.png', dpi=300, bbox_inches='tight')
    #plt.show()

    # T Average
    plt.figure()
    data = read_T_Average("../postProcessing/T_Average/0/volFieldValue.dat")
    plt.plot(data[:,0],data[:,1]-273.15)
    plt.xlabel('Iteration', fontsize=14)
    plt.ylabel('T Average', fontsize=14)  
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.savefig('T_Average_plot.png', dpi=300, bbox_inches='tight')
    #plt.show()







