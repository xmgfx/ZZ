paraview --state ./post-paraview.pvsm 
