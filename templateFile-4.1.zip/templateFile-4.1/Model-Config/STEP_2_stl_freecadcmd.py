#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import math
import Part
import Mesh

# Usage: freecadcmd STEP_2_stl_freecadcmd.py  ./aircon/出风口-通配-现代_439.STEP  ./STL_output/AC1.stl
stp = sys.argv[2]
stl = sys.argv[3]

print ('\n Convert from ', stp,' to ', stl,'\n')

shape = Part.Shape()
shape.read(stp)
shape.exportStl(stl)

