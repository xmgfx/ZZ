A=`ls aircon/aircon-3-test90-2-Deg35.step | grep "Deg" |sed 's/.*Deg\([0-9]*\).*.step/\1/'`
if [ -z "$A" ]; then
  echo "A字符串为空"
else
  echo "A字符串不为空"
fi

B=`ls aircon/aircon-3-test90-1.step | grep "Deg" | sed 's/.*Deg\([0-9]*\).*.step/\1/'`
echo $B

if [ -z "$B" ]; then
  echo "B字符串为空"
else
  echo "B字符串不为空"
fi





