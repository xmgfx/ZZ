# trace generated using paraview version 5.5.2

#### import the simple module from the paraview
from paraview.simple import *
#### disable automatic camera reset on 'Show'
paraview.simple._DisableFirstRenderCameraReset()

# create a new 'XML PolyData Reader'
yNormalvtp = XMLPolyDataReader(FileName=['./yNormal.vtp'])
yNormalvtp.PointArrayStatus = ['T', 'U']

# get active view
renderView1 = GetActiveViewOrCreate('RenderView')
# uncomment following to set a specific view size
# renderView1.ViewSize = [1950, 1696]

# show data in view
yNormalvtpDisplay = Show(yNormalvtp, renderView1)

# trace defaults for the display properties.
yNormalvtpDisplay.Representation = 'Surface'
yNormalvtpDisplay.ColorArrayName = [None, '']
yNormalvtpDisplay.OSPRayScaleArray = 'T'
yNormalvtpDisplay.OSPRayScaleFunction = 'PiecewiseFunction'
yNormalvtpDisplay.SelectOrientationVectors = 'None'
yNormalvtpDisplay.ScaleFactor = 1.1902289867401123
yNormalvtpDisplay.SelectScaleArray = 'None'
yNormalvtpDisplay.GlyphType = 'Arrow'
yNormalvtpDisplay.GlyphTableIndexArray = 'None'
yNormalvtpDisplay.GaussianRadius = 0.05951144933700562
yNormalvtpDisplay.SetScaleArray = ['POINTS', 'T']
yNormalvtpDisplay.ScaleTransferFunction = 'PiecewiseFunction'
yNormalvtpDisplay.OpacityArray = ['POINTS', 'T']
yNormalvtpDisplay.OpacityTransferFunction = 'PiecewiseFunction'
yNormalvtpDisplay.DataAxesGrid = 'GridAxesRepresentation'
yNormalvtpDisplay.SelectionCellLabelFontFile = ''
yNormalvtpDisplay.SelectionPointLabelFontFile = ''
yNormalvtpDisplay.PolarAxes = 'PolarAxesRepresentation'

# init the 'PiecewiseFunction' selected for 'ScaleTransferFunction'
yNormalvtpDisplay.ScaleTransferFunction.Points = [294.0205383300781, 0.0, 0.5, 0.0, 298.2649841308594, 1.0, 0.5, 0.0]

# init the 'PiecewiseFunction' selected for 'OpacityTransferFunction'
yNormalvtpDisplay.OpacityTransferFunction.Points = [294.0205383300781, 0.0, 0.5, 0.0, 298.2649841308594, 1.0, 0.5, 0.0]

# init the 'GridAxesRepresentation' selected for 'DataAxesGrid'
yNormalvtpDisplay.DataAxesGrid.XTitleFontFile = ''
yNormalvtpDisplay.DataAxesGrid.YTitleFontFile = ''
yNormalvtpDisplay.DataAxesGrid.ZTitleFontFile = ''
yNormalvtpDisplay.DataAxesGrid.XLabelFontFile = ''
yNormalvtpDisplay.DataAxesGrid.YLabelFontFile = ''
yNormalvtpDisplay.DataAxesGrid.ZLabelFontFile = ''

# init the 'PolarAxesRepresentation' selected for 'PolarAxes'
yNormalvtpDisplay.PolarAxes.PolarAxisTitleFontFile = ''
yNormalvtpDisplay.PolarAxes.PolarAxisLabelFontFile = ''
yNormalvtpDisplay.PolarAxes.LastRadialAxisTextFontFile = ''
yNormalvtpDisplay.PolarAxes.SecondaryRadialAxesTextFontFile = ''

# reset view to fit data
renderView1.ResetCamera()

#changing interaction mode based on data extents
renderView1.CameraPosition = [-3.883325755596161, 10001.5, 0.4795248508453369]
renderView1.CameraFocalPoint = [-3.883325755596161, 1.5, 0.4795248508453369]
renderView1.CameraViewUp = [1.0, 0.0, 0.0]

# update the view to ensure updated data information
renderView1.Update()

# set scalar coloring
ColorBy(yNormalvtpDisplay, ('POINTS', 'T'))

# rescale color and/or opacity maps used to include current data range
yNormalvtpDisplay.RescaleTransferFunctionToDataRange(True, False)

# show color bar/color legend
yNormalvtpDisplay.SetScalarBarVisibility(renderView1, True)

# get color transfer function/color map for 'T'
tLUT = GetColorTransferFunction('T')

# hide color bar/color legend
yNormalvtpDisplay.SetScalarBarVisibility(renderView1, False)

# current camera placement for renderView1
renderView1.InteractionMode = '2D'
renderView1.CameraPosition = [-3.883325755596161, 10001.5, 0.4795248508453369]
renderView1.CameraFocalPoint = [-3.883325755596161, 1.5, 0.4795248508453369]
renderView1.CameraViewUp = [1.0, 0.0, 0.0]
renderView1.CameraParallelScale = 8.153272043716132

# save screenshot
SaveScreenshot('./cuttingPlane_T.png', renderView1, ImageResolution=[1950, 1696],
    OverrideColorPalette='WhiteBackground')

#### saving camera placements for all active views

# current camera placement for renderView1
renderView1.InteractionMode = '2D'
renderView1.CameraPosition = [-3.883325755596161, 10001.5, 0.4795248508453369]
renderView1.CameraFocalPoint = [-3.883325755596161, 1.5, 0.4795248508453369]
renderView1.CameraViewUp = [1.0, 0.0, 0.0]
renderView1.CameraParallelScale = 8.153272043716132

#### uncomment the following to render all views
# RenderAllViews()
# alternatively, if you want to write images, you can use SaveScreenshot(...).
