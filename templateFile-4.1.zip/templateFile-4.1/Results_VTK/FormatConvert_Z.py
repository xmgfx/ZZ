# trace generated using paraview version 5.6.0
#
# To ensure correct image size when batch processing, please search 
# for and uncomment the line `# renderView*.ViewSize = [*,*]`

#### import the simple module from the paraview
from paraview.simple import *
#### disable automatic camera reset on 'Show'
paraview.simple._DisableFirstRenderCameraReset()

# create a new 'XML PolyData Reader'
yNormalvtp = XMLPolyDataReader(FileName=['./zNormal.vtp'])
yNormalvtp.PointArrayStatus = ['T', 'U']

# get active view
renderView1 = GetActiveViewOrCreate('RenderView')
# uncomment following to set a specific view size
# renderView1.ViewSize = [2175, 1673]

# show data in view
yNormalvtpDisplay = Show(yNormalvtp, renderView1)

# trace defaults for the display properties.
yNormalvtpDisplay.Representation = 'Surface'
yNormalvtpDisplay.ColorArrayName = [None, '']
yNormalvtpDisplay.OSPRayScaleArray = 'T'
yNormalvtpDisplay.OSPRayScaleFunction = 'PiecewiseFunction'
yNormalvtpDisplay.SelectOrientationVectors = 'None'
yNormalvtpDisplay.ScaleFactor = 1.1902289867401123
yNormalvtpDisplay.SelectScaleArray = 'None'
yNormalvtpDisplay.GlyphType = 'Arrow'
yNormalvtpDisplay.GlyphTableIndexArray = 'None'
yNormalvtpDisplay.GaussianRadius = 0.05951144933700562
yNormalvtpDisplay.SetScaleArray = ['POINTS', 'T']
yNormalvtpDisplay.ScaleTransferFunction = 'PiecewiseFunction'
yNormalvtpDisplay.OpacityArray = ['POINTS', 'T']
yNormalvtpDisplay.OpacityTransferFunction = 'PiecewiseFunction'
yNormalvtpDisplay.DataAxesGrid = 'GridAxesRepresentation'
yNormalvtpDisplay.SelectionCellLabelFontFile = ''
yNormalvtpDisplay.SelectionPointLabelFontFile = ''
yNormalvtpDisplay.PolarAxes = 'PolarAxesRepresentation'

# init the 'GridAxesRepresentation' selected for 'DataAxesGrid'
yNormalvtpDisplay.DataAxesGrid.XTitleFontFile = ''
yNormalvtpDisplay.DataAxesGrid.YTitleFontFile = ''
yNormalvtpDisplay.DataAxesGrid.ZTitleFontFile = ''
yNormalvtpDisplay.DataAxesGrid.XLabelFontFile = ''
yNormalvtpDisplay.DataAxesGrid.YLabelFontFile = ''
yNormalvtpDisplay.DataAxesGrid.ZLabelFontFile = ''

# init the 'PolarAxesRepresentation' selected for 'PolarAxes'
yNormalvtpDisplay.PolarAxes.PolarAxisTitleFontFile = ''
yNormalvtpDisplay.PolarAxes.PolarAxisLabelFontFile = ''
yNormalvtpDisplay.PolarAxes.LastRadialAxisTextFontFile = ''
yNormalvtpDisplay.PolarAxes.SecondaryRadialAxesTextFontFile = ''

# reset view to fit data
renderView1.ResetCamera()

#changing interaction mode based on data extents
renderView1.InteractionMode = '2D'
renderView1.CameraPosition = [-3.883325755596161, 10001.5, 0.4795248508453369]
renderView1.CameraFocalPoint = [-3.883325755596161, 1.5, 0.4795248508453369]
renderView1.CameraViewUp = [1.0, 0.0, 0.0]

# get the material library
materialLibrary1 = GetMaterialLibrary()

# update the view to ensure updated data information
renderView1.Update()

# set scalar coloring
ColorBy(yNormalvtpDisplay, ('POINTS', 'T'))

# rescale color and/or opacity maps used to include current data range
yNormalvtpDisplay.RescaleTransferFunctionToDataRange(True, False)

# show color bar/color legend
yNormalvtpDisplay.SetScalarBarVisibility(renderView1, True)

# get color transfer function/color map for 'T'
tLUT = GetColorTransferFunction('T')

# get opacity transfer function/opacity map for 'T'
tPWF = GetOpacityTransferFunction('T')

# save data
SaveData('./zNormal_ascii.vtp', proxy=yNormalvtp, DataMode='Ascii')

#### saving camera placements for all active views

# current camera placement for renderView1
renderView1.InteractionMode = '2D'
renderView1.CameraPosition = [-3.883325755596161, 10001.5, 0.4795248508453369]
renderView1.CameraFocalPoint = [-3.883325755596161, 1.5, 0.4795248508453369]
renderView1.CameraViewUp = [1.0, 0.0, 0.0]
renderView1.CameraParallelScale = 8.153272043716132

#### uncomment the following to render all views
# RenderAllViews()
# alternatively, if you want to write images, you can use SaveScreenshot(...).
